<template>
	<div id="tmpl">
		购物车
	</div>
</template>

<script>
		export default{

}
</script>

		<style scoped>

</style>